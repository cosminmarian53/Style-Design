
//-------------------------N A V B A R -------------------------------------------

// window.onscroll = function() {scrollFunction()};
// function scrollFunction() {
//     if (document.body.scrollTop > 5 || document.documentElement.scrollTop > 5) {
//       document.getElementById("navbar").style.backgroundColor = "default";
//       document.getElementById("navbar").style.marginTop = "0";
//       document.getElementById("navbar").style.backdropFilter = "blur(15px)";
//       document.getElementById("logo").style.filter = "invert(0%)";
//     } else {
//        document.getElementById("navbar").style.backgroundColor = "transparent";
//        document.getElementById("navbar").style.marginTop = "50px";
//        document.getElementById("navbar").style.backdropFilter = "blur(0px)";
//        document.getElementById("logo").style.filter = "invert(100%)";
//     }
//   }



//------------------ D A R K   M O D E   B T N -------------------------------------


