async function BindRandomImage(Camera,Tip,ID)
{
    var FORM = new FormData();
    



    FORM.append("Camera",Camera)
    FORM.append("Tip",Tip);
    FORM.append("ID",ID);

    

    var AJAX = await fetch("/Backend/RandomImage.php", {
     
        method:"POST",
        body: FORM,
        headers: {
            'Access-Control-Allow-Origin':'*'
          }

    });

    

   var Response = await AJAX.json();




   var div = document.getElementById(ID);
   div.style.backgroundImage = 'url(Produse/'+ Camera + '/' + Response +'.jpg'+')';
  
   
  
}



async function CreateProductDiv(ID, camera, tip )
{
    var FORM = new FormData();
    
    FORM.append('ID',ID);
    FORM.append('Camera',camera);
    FORM.append('tip',tip);
    


    var AJAX = await fetch("/Backend/CreateSpecifDiv.php", 
    {
     
        method:"POST",
        body: FORM,
        headers: {
            'Access-Control-Allow-Origin':'*'
          }

    });

    var Response = await AJAX.json();

    

    var product = document.createElement('f1');
    product.style.backgroundImage = 'url(Produse/'+ camera + '/' + Response +'.jpg'+')';

    var Container = document.getElementById('container');
    Container.appendChild(product);

}

async function CreateXtoYProducts(X,Y,camera,tip)
{
    for(var i=X;i<=Y;i++)
    {
        CreateProductDiv(i,camera,tip);
    }

}


