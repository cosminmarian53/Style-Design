<?php

$CONFIG = 'CONFIG.php';
if(file_exists($CONFIG))
include($CONFIG);
else die("CONFIG missing/corrupted");



$user  = 'root';
$pass = '';
$db = 'mobila2';
$host = 'localhost';

$dbc =  new mysqli($host,$user,$pass,$db);

$cam  = $_POST['Camera'];
$tip  = $_POST['tip'];
$ID   = $_POST['ID']; 




$response = $dbc->query("SELECT Nume FROM $cam WHERE ID =$ID ");

$result = $response->fetch_assoc();

if($result == null )
return 69;

else
{
   
header('Content-Type: application/json');

echo json_encode($result['Nume']);

}


?>