<?php
/*
$user  = 'root';
$pass = '';
$db = 'mobila2';
$host = 'localhost';

$dbc =  new mysqli($host,$user,$pass,$db);
*/



$CONFIG = 'CONFIG.php';

//header('Access-Control-Allow-Origin: *');

if(file_exists($CONFIG)) {include $CONFIG;}
else die('"Config missing or corrupted"');


$camera = $_POST['Camera'];
$tip = $_POST['Tip'];
$div_id = $_POST['ID'];



$tip = $dbc->real_escape_string($tip);
$camera = $dbc->real_escape_string($camera);
/*
$statement =$dbc->prepare("SELECT Nume FROM $camera WHERE Tip LIKE ? ");
$statement->bind_param("s",$tip);
$statement->execute();
$res = $statement->get_result();
*/

$res = $dbc->query("SELECT Nume FROM $camera WHERE Tip LIKE '$tip' ");

try{

$Index = random_int(1, $res->num_rows);

$res->data_seek($Index - 1);
$row = $res->fetch_assoc();



header('Content-Type: application/json');
echo json_encode($row["Nume"]);
}
catch(Exception $ex)
{
    $file = fopen("crashReport.txt", "a");
    fwrite($file, "Eroare \n" . $ex->getMessage());
    fclose($file);
}

$date = date ('H:I:S d/m/Y' );
$file = fopen("crashReport.txt", "a");
fwrite($file, "Script functioned at".$date."\n");
fclose($file);

?>