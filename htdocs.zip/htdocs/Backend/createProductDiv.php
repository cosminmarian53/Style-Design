<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS');




$CONFIG='CONFIG.php';

if(file_exists($CONFIG))
    include($CONFIG);
else die("CONFIG missing/corrupted");


$ID = $_POST['ID'];
$camera = $_POST['Camera'];
$tip = $_POST['tip'];

/*
$statement = $dbc->prepare("SELECT Nume FROM $camera where Tip Like '$tip' AND ID = $ID ");

$statement->execute();
$res = $statement->get_result();*/

$res = $dbc->query("SELECT * FROM 'baie' where Tip Like '$tip'");

$row = $res->fetch_assoc();


$file = fopen("returnedNumbers.txt", "a");
fwrite($file, $row['Nume']);
fclose($file);





header('Content-Type: application/json');



echo json_encode($row['Nume']);




?>