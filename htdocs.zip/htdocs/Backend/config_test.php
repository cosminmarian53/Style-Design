<?php
/*
$user  = 'root';
$pass = '';
$db = 'mobila2';
$host = 'localhost';

$dbc =  new mysqli($host,$user,$pass,$db);
*/



$CONFIG = 'CONFIG.php';

//header('Access-Control-Allow-Origin: *');

if(file_exists($CONFIG)) {include $CONFIG;}
else die('"Config missing or corrupted"');


$camera = $_POST['Camera'];
$tip = $_POST['Tip'];
$div_id = $_POST['ID'];



$tip = $dbc->real_escape_string($tip);
$camera = $dbc->real_escape_string($camera);

$res = $dbc->query("SELECT Nume FROM $camera WHERE Tip LIKE '$tip' AND ID = $div_id ");

try{

$Index = random_int(1, $res->num_rows);

$row = $res->fetch_assoc();



header('Content-Type: application/json');
echo json_encode($row["Nume"]);


}
catch(Exception $ex)
{
    $file = fopen("crashReport.txt", "a");
    fwrite($file, "Am facut bubu\n" . $ex->getMessage());
    fclose($file);
}

$date = date ('H:I:S d/m/Y' );
$file = fopen("crashReport.txt", "a");
fwrite($file, "Script functioned at".$date."\n");
fclose($file);

?>