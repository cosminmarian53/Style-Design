<?php

$user  = 'root';
$pass = '';
$db = 'mobila2';
$host = 'localhost';

$dbc =  new mysqli($host,$user,$pass,$db);

?>